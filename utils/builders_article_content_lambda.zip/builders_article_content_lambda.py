import json
import urllib.request
import urllib.error
import urllib.parse


def _cors_headers():
    return {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': 'GET, OPTIONS',
    }


def lambda_handler(event, context):
    """
    AWS Lambda function that fetches ARTICLE content from the AWS Builders API.

    Performs a GET request to:
      https://api.builder.aws.com/cs/content?cid=<cid>&commentSort=NEWEST&type=ARTICLE

    - cid: article content id. Accepts raw (e.g., "/content/..."), or already URL-encoded.
    - commentSort: fixed to NEWEST
    - type: fixed to ARTICLE
    """

    # Handle CORS preflight
    http_method = (event or {}).get('httpMethod') or (event or {}).get('requestContext', {}).get('http', {}).get('method')
    if http_method == 'OPTIONS':
        return {
            'statusCode': 200,
            'headers': _cors_headers(),
            'body': ''
        }

    api_url = "https://api.builder.aws.com/cs/content"

    # Extract cid from query string or body
    cid_value = None
    query_params = (event or {}).get('queryStringParameters') or {}
    if isinstance(query_params, dict):
        cid_value = query_params.get('cid')

    if not cid_value:
        # Try JSON body
        body = (event or {}).get('body')
        if body:
            try:
                parsed_body = json.loads(body) if isinstance(body, str) else body
                if isinstance(parsed_body, dict):
                    cid_value = parsed_body.get('cid')
            except Exception:
                # Ignore body parse errors, handled below as missing cid
                pass

    if not cid_value:
        return {
            'statusCode': 400,
            'headers': _cors_headers(),
            'body': json.dumps({'error': 'Missing required parameter: cid'})
        }

    # Normalize and encode cid for querystring
    # Accept both raw ("/content/...") and already-encoded values
    try:
        cid_decoded = urllib.parse.unquote(cid_value)
    except Exception:
        cid_decoded = cid_value

    query = {
        'cid': cid_decoded,
        'commentSort': 'NEWEST',
        'type': 'ARTICLE',
    }
    full_url = f"{api_url}?{urllib.parse.urlencode(query)}"

    headers = {
        'builder-session-token': 'dummy',
        'Accept': 'application/json',
    }

    try:
        req = urllib.request.Request(
            full_url,
            headers=headers,
            method='GET'
        )

        with urllib.request.urlopen(req, timeout=30) as resp:
            status_code = resp.getcode()
            resp_body_bytes = resp.read()
            resp_text = resp_body_bytes.decode('utf-8') if resp_body_bytes else ''

            if status_code == 200:
                # Forward JSON when possible
                try:
                    parsed = json.loads(resp_text) if resp_text else {}
                    proxy_body = json.dumps(parsed)
                except json.JSONDecodeError:
                    proxy_body = resp_text

                return {
                    'statusCode': 200,
                    'headers': _cors_headers(),
                    'body': proxy_body,
                }

            return {
                'statusCode': status_code,
                'headers': _cors_headers(),
                'body': json.dumps({
                    'error': f'API request failed with status {status_code}',
                    'message': resp_text,
                }),
            }

    except urllib.error.HTTPError as e:
        err_text = e.read().decode('utf-8') if e.fp else ''
        return {
            'statusCode': e.code if hasattr(e, 'code') else 500,
            'headers': _cors_headers(),
            'body': json.dumps({
                'error': 'Upstream HTTP error',
                'message': err_text or str(e),
            })
        }
    except urllib.error.URLError as e:
        return {
            'statusCode': 500,
            'headers': _cors_headers(),
            'body': json.dumps({
                'error': 'Network error while calling upstream',
                'message': str(e),
            })
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'headers': _cors_headers(),
            'body': json.dumps({
                'error': 'Unexpected error occurred',
                'message': str(e),
            })
        }


